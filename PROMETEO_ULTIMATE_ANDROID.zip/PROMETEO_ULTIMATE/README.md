# PROMETEO ULTIMATE

Hub principale · COSMO demo · ruoli ZEUS / ADE / Poseidone

## Avvio su Android
1. Estrai la cartella sul PC o pubblicala su un hosting HTTPS.
2. Apri l'indirizzo `index.html` tramite un server web locale/HTTPS (i Service Worker non funzionano correttamente da `file://`).
3. In Chrome Android: menu ⋮ → **Installa app** oppure **Aggiungi a schermata Home**.
4. Dopo il primo caricamento, l'interfaccia è disponibile offline.

Per test locale da PC: dalla cartella dell'app esegui `python -m http.server 8000` e apri `http://localhost:8000`. Per installazione sul telefono, usa HTTPS o un server locale raggiungibile dal telefono.

## Limiti dichiarati
Questa è una PWA installabile, non un APK nativo. Il motore di chat è locale dimostrativo; non include un modello AI, backend, account, MFA, sincronizzazione cloud o integrazioni hardware. I ruoli e COSMO in ULTIMATE sono simulazioni UI e non sicurezza reale. Non usare per proteggere dati o gestire utenti reali.
